//
//  ViewController.swift
//  SimpleLoaderDemo
//
//  Created by Alfredo Uzumaki on 6/6/19.
//  Copyright © 2019 Alfredo Uzumaki. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func actionButton(_ sender: Any) {
        loader.isAnimating ? hideLoader() : showLoader()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

